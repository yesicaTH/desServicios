export default {
    user: "user_node",
    host: "localhost",
    database: "bd_universidad", 
    password: "123456",
    port: 5432,
}