import {Request, Response} from 'express';
import PensumDAO from '../daos/PensumDAO';
import {SQL_PENSUMS} from '../repositorios/pensums_sql';

class PensumControlador extends PensumDAO{

    public demeLosPensum(req: Request, res: Response): void{
        PensumControlador.obenerPensum(SQL_PENSUMS.TODAS, [], res);
    }
    public averGrabalo(req: Request, res: Response): void {
        const nombre = req.body.nombrePensum;
        const codprogram = req.body.codPrograma;
        const parametro = [codprogram, nombre];
        PensumControlador.crearPensum(SQL_PENSUMS.CONFIRMAR, SQL_PENSUMS.CREAR, parametro, res);
    }
    public busqueUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        PensumControlador.encontrarPorID(SQL_PENSUMS.CARGAR, parametro,res);
    }
    public BorreUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        PensumControlador.eliminarPorID(SQL_PENSUMS.BORRAR, parametro,res);
    }
}
const pensumControlador = new PensumControlador();
export default pensumControlador;