import {Request, Response} from 'express';
import MateriaPensumDAO from '../daos/MateriaPensumDAO';
import PensumDAO from '../daos/MateriaPensumDAO';
import {SQL_MATERIAPENSUM} from '../repositorios/materiapensum_sql';

class MateriaPensumControlador extends MateriaPensumDAO{

    public demeLosMateriaPensum(req: Request, res: Response): void{
        MateriaPensumControlador.obenerMateriaPensum(SQL_MATERIAPENSUM.TODAS, [], res);
    }
}
const materiaPensumControlador = new MateriaPensumControlador();
export default materiaPensumControlador;