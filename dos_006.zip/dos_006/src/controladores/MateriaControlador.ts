import {Request, Response} from 'express';
import MateriaDAO from '../daos/MateriaDAO';
import {SQL_MATERIAS} from '../repositorios/materias_sql';

class MateriaControlador extends MateriaDAO{

    public demeLasMaterias(req: Request, res: Response): void{
        MateriaControlador.obenerMateria(SQL_MATERIAS.TODAS, [], res);
    }
    public averGrabalo(req: Request, res: Response): void {
        const nombre = req.body.nombreMateria;
        const refmateria = req.body.referenciaMateria;
        const parametro = [nombre, refmateria];
        MateriaControlador.crearMateria(SQL_MATERIAS.CONFIRMAR, SQL_MATERIAS.CREAR, parametro, res);
    }
    public busqueUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        MateriaControlador.encontrarPorID(SQL_MATERIAS.CARGAR, parametro,res);
    }
    public BorreUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        MateriaControlador.eliminarPorID(SQL_MATERIAS.BORRAR, parametro,res);
    }
}
const materiaControlador = new MateriaControlador();
export default materiaControlador;