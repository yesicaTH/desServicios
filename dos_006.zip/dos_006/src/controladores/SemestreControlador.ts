import {Request, Response} from 'express';
import SemestreDAO from '../daos/SemestreDAO';
import {SQL_SEMESTRES} from '../repositorios/semestres_sql';

class SemestreControlador extends SemestreDAO{

    public demeLosSemestres(req: Request, res: Response): void{
        SemestreControlador.obenerSemestre(SQL_SEMESTRES.TODAS, [], res);
    }
    public averGrabalo(req: Request, res: Response): void {
        const nombre = req.body.nombreSemestre;
        const parametro = [nombre];
        SemestreControlador.crearSemestre(SQL_SEMESTRES.CONFIRMAR, SQL_SEMESTRES.CREAR, parametro, res);
    }
    public busqueUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        SemestreControlador.encontrarPorID(SQL_SEMESTRES.CARGAR, parametro,res);
    }
    public BorreUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        SemestreControlador.eliminarPorID(SQL_SEMESTRES.BORRAR, parametro,res);
    }

}
const semestreControlador = new SemestreControlador();
export default semestreControlador;