import {Request, Response} from 'express';
import ProgramaDAO from '../daos/ProgramaDAO';
import {SQL_PROGRAMAS} from '../repositorios/programas_sql';

class ProgramaControlador extends ProgramaDAO{

    public demeLosProgramas(req: Request, res: Response): void{
        ProgramaControlador.obenerPrograma(SQL_PROGRAMAS.TODAS, [], res);
    }

    public averGrabalo(req: Request, res: Response): void {
        const nombre = req.body.nombrePrograma;
        const parametro = [nombre];
        ProgramaControlador.crearPrograma(SQL_PROGRAMAS.CONFIRMAR, SQL_PROGRAMAS.CREAR, parametro, res);
    }
    public busqueUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        ProgramaControlador.encontrarPorID(SQL_PROGRAMAS.CARGAR, parametro,res);
    }
    public BorreUno(req: Request, res: Response): void {
        const codiguito = req.params.elCodigo;
        const parametro = [codiguito];
        ProgramaControlador.eliminarPorID(SQL_PROGRAMAS.BORRAR, parametro,res);
    }

}
const programaControlador = new ProgramaControlador();
export default programaControlador;