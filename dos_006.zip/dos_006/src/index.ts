import Servidor  from "./configuracion/api/Servidor";

const servidor = new Servidor();
servidor.iniciar();