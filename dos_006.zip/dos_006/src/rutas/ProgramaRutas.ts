import {Router} from 'express';
import materiaControlador from '../controladores/MateriaControlador';
import materiaPensumControlador from '../controladores/MateriaPensumControlador';
import pensumControlador from '../controladores/PensumControlador';
import programaControlador from '../controladores/ProgramaControlador';
import semestreControlador from '../controladores/SemestreControlador';

import programaControlador_Actualizar from '../controladores/programas/ProgramaControlador_Actualizar';
import programaControlador_Crear from '../controladores/programas/ProgramaControlador_Crear';
import programaControlador_Listar from '../controladores/programas/ProgramaControlador_Listar';
import programaControlador_Buscar from '../controladores/programas/ProgramaControlador_Buscar';
import programaControlador_Eliminar from '../controladores/programas/ProgramaControlador_Eliminar';

class ProgramaRutas{

    public rutaProgramaApi:Router;

    constructor(){
        this.rutaProgramaApi = Router();
        this.configuracion();
    }
    public configuracion(){
        this.rutaProgramaApi.get('/programa', programaControlador_Listar.demeLosProgramas);
        this.rutaProgramaApi.post('/programa/crear', programaControlador_Crear.grabarPrograma);
        this.rutaProgramaApi.get('/programa/:elCodigo', programaControlador_Buscar.busqueUno);
        this.rutaProgramaApi.delete('/programa/:elCodigo', programaControlador_Eliminar.BorreUno);
        this.rutaProgramaApi.put('/programa/actualizar', programaControlador_Actualizar.actualizar);

        this.rutaProgramaApi.get('/semestre', semestreControlador.demeLosSemestres);
        this.rutaProgramaApi.post('/semestre/crear', semestreControlador.averGrabalo);
        this.rutaProgramaApi.get('/semestre/:elCodigo', semestreControlador.busqueUno);
        this.rutaProgramaApi.delete('/semestre/:elCodigo', semestreControlador.BorreUno);

        this.rutaProgramaApi.get('/materia', materiaControlador.demeLasMaterias);
        this.rutaProgramaApi.post('/materia/crear', materiaControlador.averGrabalo);
        this.rutaProgramaApi.get('/materia/:elCodigo', materiaControlador.busqueUno);
        this.rutaProgramaApi.delete('/materia/:elCodigo', materiaControlador.BorreUno);

        this.rutaProgramaApi.get('/pensum', pensumControlador.demeLosPensum);
        this.rutaProgramaApi.post('/pensum/crear', pensumControlador.averGrabalo);
        this.rutaProgramaApi.get('/pensum/:elCodigo', pensumControlador.busqueUno);
        this.rutaProgramaApi.delete('/pensum/:elCodigo', pensumControlador.BorreUno);

        this.rutaProgramaApi.get('/materiapensum', materiaPensumControlador.demeLosMateriaPensum);
    }
}
const programaRutas = new ProgramaRutas();
export default programaRutas.rutaProgramaApi;