export const SQL_PROGRAMAS_ELIMINAR= {

    BORRAR: 'DELETE FROM programas WHERE cod_programa = $1'
}