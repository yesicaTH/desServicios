export const SQL_PROGRAMAS_ACTUALIZAR = {

    ACTUALIZAR: 'UPDATE programas SET nombre_programa = $1 WHERE cod_programa = $2'
}